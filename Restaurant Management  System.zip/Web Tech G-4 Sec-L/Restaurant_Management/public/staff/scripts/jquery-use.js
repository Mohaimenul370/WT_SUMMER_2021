$(document).ready(function () {
  // Pre-loader
  $('#loader-container').fadeOut(1000);
});
