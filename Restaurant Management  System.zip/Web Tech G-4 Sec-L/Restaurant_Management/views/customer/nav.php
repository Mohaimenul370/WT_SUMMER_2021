<nav class="nav">
    <ul>
        <li><a href="allCustomer.php">All Customers</a></li>
        <li><a href="CustomerView.php">View Profile</a></li>
        <li><a href="CustomerEdit.php">Edit Profile</a></li>        
        <li><a href="CustomerDelete.php">Delete Profile</a></li>
        <li><a href="CustomerLogout.php">Logout</a></a></li>
    </ul> 
</nav>