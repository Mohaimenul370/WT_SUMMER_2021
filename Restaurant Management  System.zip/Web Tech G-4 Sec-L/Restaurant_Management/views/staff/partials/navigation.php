<nav class="navbar">
    <ul>
        <li><a href="view.php">View</a></li>
        <li><a href="edit.php">Edit profile</a></li>
        <li><a href="allStaff.php">All Staffs</a></li>
        <li><a href="inventory.php">Menu</a></li>
        <li><a href="delete.php">Delete profile</a></li>
        <li><a href="logout.php">Logout</a></a></li>
    </ul> 
</nav>