<?php

    include('../../../controls/staff/showCertainStaff-controller.php');

    $output =  $userQuery;
    echo $output;
    
    

?>